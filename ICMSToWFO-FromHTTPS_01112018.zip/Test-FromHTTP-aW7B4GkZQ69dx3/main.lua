local validate = require 'validate'
local retry = require 'retry'

local temp=[[

<roster>
<id></id>
<employee-code></employee-code>
<roster-date></roster-date>
<workspace-code></workspace-code>
<shift-code></shift-code>
<start-time></start-time>
<end-time></end-time>
<status></status>
<break-duration></break-duration>
</roster>
]]

--local function ProcessMSG(XMLMsg)
  -- local Errs = validate.CheckAdt(XMLMsg) 
  -- if (#Errs > 0) then
     -- Respond= net.http.respond{body="Error Occured " .. table.concat(Errs)}
     -- return    Errs
  -- end
--end

local function TrimField(F)


   for i=1, F.rosters:childCount("roster") do
      -- for j=1, F.rosters:childCount("roster") do
      F.rosters:child("roster", i).id:setInner(F.rosters:child("roster", i).id:nodeText():trimWS())
      F.rosters:child("roster", i)["employee-code"]:setInner(F.rosters:child("roster", i)["employee-code"]:nodeText():trimWS())
      F.rosters:child("roster", i)["roster-date"]:setInner(F.rosters:child("roster", i)["roster-date"]:nodeText():trimWS())
      F.rosters:child("roster", i)["workspace-code"]:setInner(F.rosters:child("roster", i)["workspace-code"]:nodeText():trimWS())
      F.rosters:child("roster", i)["shift-code"]:setInner( F.rosters:child("roster", i)["shift-code"]:nodeText():trimWS())
      F.rosters:child("roster", i)["start-time"]:setInner(F.rosters:child("roster", i)["start-time"]:nodeText():trimWS())
      F.rosters:child("roster", i)["end-time"]:setInner(F.rosters:child("roster", i)["end-time"]:nodeText():trimWS())
      F.rosters:child("roster", i).status:setInner(F.rosters:child("roster", i).status:nodeText():trimWS())
      F.rosters:child("roster", i)["break-duration"]:setInner(F.rosters:child("roster", i)["break-duration"]:nodeText():trimWS())

      if  F.rosters:child("roster", i)["break-duration"]:nodeText() == '' then
         F.rosters:child("roster", i)["break-duration"]:setInner(0)

      end

      --end   
   end
   return F
end

function main(Data)

   local Result, R2, M = retry.call{func=DoInsert, retry=10, pause=10, funcname='DoInsert',arg1=Data}
   trace(Result)
   trace(R2)
   trace(M)

   

   if #R2 == 0 then 



      local response, status, headers = 
      net.http.put{url='http://test.workforceoptimizer.com/api/schedule', data = Result, live=true,
         auth={username='sysadmin@stgsgh49.com',password='Password1'},headers={['Content-Type']='application/xml'}}  


      -- Log the response and status code
      if status == 200 then
         iguana.logDebug("Request successful: " .. "(" ..status .. ")".. response )  
         iguana.logInfo("Request successful: " .. "(" ..status .. ")".. response ) 
         net.http.respond{body="Code : " .. status..", Success \n".. response,entity_type='text/xml'}
      elseif status == 400 then
         iguana.logDebug("Validation Error: " .. "(" ..status .. ")".. response )
         net.http.respond{body="Code : " .. status.." , Success \n".. response,entity_type='text/xml'}
      elseif status == 401 then
         iguana.logDebug("Unauthorize Error: " .. "(" ..status .. ")".. response )
         net.http.respond{body="Code : " .. status..", Success \n".. response,entity_type='text/xml'}
      elseif status == 500 then
         iguana.logDebug("error Internal Server Error" .. "(" ..status .. ")".. response )
         net.http.respond{body="Code : ".. status..", Success \n".. response,entity_type='text/xml'}
      else
         iguana.logDebug("Request unsuccessful: "  .. "(" ..status .. ")".. response )
         net.http.respond{body="Code : ".. status..", Success \n".. response,entity_type='text/xml'}


      end
   else
      net.http.respond{body=" Error Occured " .. table.concat(R2)}
      print("error Occured")
      iguana.logDebug("Error Occured" .. table.concat(R2))
   end

end

function DoInsert(Data)
   --Parse the incoming request
   Request = net.http.parseRequest{data=Data}
   --log the info 
   iguana.logInfo(Data)
   --parse the xml message
   ParseMsg= xml.parse{data=Request.body}
   --trim whitespce before and after
   local XMLMsg= TrimField(ParseMsg)
   --parse XML template
   local XMLTemplate=xml.parse{data=temp}


   --start validating
   local ValidateErrs=validate.CheckAdt(XMLMsg)
   
   if  #ValidateErrs == 0 then

      --mapping the data
      local Result = mapdata(XMLTemplate,XMLMsg)
      queue.push{data=Result}
      trace(Result)
      return Result,ValidateErrs
   end
   
  return Result,ValidateErrs

end

function mapdata(Xml,XMLMsg)
   Result = {}


   for i=1, XMLMsg.rosters:childCount('roster') do


      Xml.roster.id:setInner(XMLMsg.rosters:child("roster", i).id:nodeText())
      Xml.roster["employee-code"]:setInner(XMLMsg.rosters:child("roster", i)["employee-code"]:nodeText())
      Xml.roster["roster-date"]:setInner(XMLMsg.rosters:child("roster", i)["roster-date"]:nodeText())
      Xml.roster["workspace-code"]:setInner(XMLMsg.rosters:child("roster", i)["workspace-code"]:nodeText())
      Xml.roster["shift-code"]:setInner(XMLMsg.rosters:child("roster", i)["shift-code"]:nodeText())
      Xml.roster["start-time"]:setInner(XMLMsg.rosters:child("roster", i)["start-time"]:nodeText())
      Xml.roster["end-time"]:setInner(XMLMsg.rosters:child("roster", i)["end-time"]:nodeText())
      Xml.roster.status:setInner(XMLMsg.rosters:child("roster", i).status:nodeText())
      Xml.roster["break-duration"]:setInner(XMLMsg.rosters:child("roster", i)["break-duration"]:nodeText())


      trace(Xml)

      --convert to string      
      Result[i]=Xml:S().."\n"
   end   
   return formatresult(Result)
end
function formatresult(Result)
  -- trace(#Result)
   local Output = 
   "<rosters>\n"..table.concat(Result).."</rosters>"
   return Output,'text/xml'
end




