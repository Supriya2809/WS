local codemap = require 'codemap' 
 
local validate={}

--local SexSet = codemap.set{'Female', 'Male'}
local Shiftcode = codemap.set{'ICMS', 'HCMS'}
local Status = codemap.set{'A','C'}
  -- local IDLength = 4
   --local EcodeLength = 7
 
local function Add(List, Msg)
   List[#List+1] = Msg
end
 
local function EmptyList()
   local List = {}
   List.add = Add
   return List
end
 

local function RequiredField(Errs, F, Message, rosterid)
   trace(F)
  
   if F:nodeText() == '' then
      Errs:add(Message..' not present for rosterid '.. rosterid:nodeText())
      return Errs[#Errs]
   end
end
 


local  function ComputeTime(Errs, starttime, endtime, rosterid)
   time=os.ts.difftime(endtime:nodeText(),starttime:nodeText())
   trace(time)
   if time < 0 then
      Errs:add("Start Time (".. starttime:nodeText().. ") is greater than End Time (" 
         .. endtime:nodeText() .. ") for roster id " .. rosterid:nodeText())
   return Errs[#Errs]   
   end

end

local function FieldMatchCode(Errs, Set, F, Message,rosterid)
   if not Set[F:nodeText()] then
      Errs:add("Shift code has unacceptable values '".. F:nodeText().. "' for roster id " ..rosterid:nodeText())
      return Errs[#Errs]
   end
end

local function FieldLength(Errs, len, F, Message, rosterid)
   if string.len( F:nodeText())> len then
      Errs:add(Message .. " has exceeded the string lenght limit for roster id " .. rosterid:nodeText() .." Limit is: " .. len)
      return Errs[#Errs]
   end
end

 
local function CheckField(XMLMsg, Errs)
   for i=1, XMLMsg.rosters:childCount('roster') do
   
   RequiredField(Errs, XMLMsg.rosters:child("roster", i).id, 'id', XMLMsg.rosters:child("roster", i).id)
   RequiredField(Errs, XMLMsg.rosters:child("roster", i)["employee-code"], 'employee-code', XMLMsg.rosters:child("roster", i).id)
   RequiredField(Errs, XMLMsg.rosters:child("roster", i)["roster-date"], 'roster-date', XMLMsg.rosters:child("roster", i).id)
   RequiredField(Errs, XMLMsg.rosters:child("roster", i)["workspace-code"], 'workspace-code', XMLMsg.rosters:child("roster", i).id)
   RequiredField(Errs, XMLMsg.rosters:child("roster", i)["shift-code"], 'shift-code', XMLMsg.rosters:child("roster", i).id)
   RequiredField(Errs, XMLMsg.rosters:child("roster", i)["start-time"], 'start-time', XMLMsg.rosters:child("roster", i).id)
   RequiredField(Errs, XMLMsg.rosters:child("roster", i)["end-time"], 'end-time', XMLMsg.rosters:child("roster", i).id)
   RequiredField(Errs, XMLMsg.rosters:child("roster", i).status, 'status', XMLMsg.rosters:child("roster", i).status)
   RequiredField(Errs, XMLMsg.rosters:child("roster", i)["break-duration"], 'break-duration', XMLMsg.rosters:child("roster", i).id)
      

   ComputeTime(Errs, XMLMsg.rosters:child("roster", i)["start-time"], XMLMsg.rosters:child("roster", i)["end-time"], XMLMsg.rosters:child("roster", i).id)
   FieldMatchCode(Errs, Shiftcode,  XMLMsg.rosters:child("roster", i)["shift-code"], 'shift code', XMLMsg.rosters:child("roster", i).id)
   FieldMatchCode(Errs, Status,  XMLMsg.rosters:child("roster", i).status, 'status', XMLMsg.rosters:child("roster", i).id)
         --FieldLength(Errs, IDLength, XMLMsg.rosters:child("roster", i).id , 'roster.id', XMLMsg.rosters:child("roster", i).id)
   --FieldLength(Errs, EcodeLength, XMLMsg.rosters:child("roster", i)["employee-code"], 'roster.employee-code', XMLMsg.rosters:child("roster", i).id)
   end
end
 
function validate.CheckAdt(XMLMsg)
   local ErrList = EmptyList()   
   CheckField(XMLMsg, ErrList)
   ErrList.add = nil
   return ErrList
end

local function PrintSet(Set)
   local R =''
   for K in pairs(Set) do
      R = R..",'"..K.."'"
   end
   R = '['..R:sub(2, #R)..']'
   return R
end
--modify the function call to match the code for shift code)


 
return validate