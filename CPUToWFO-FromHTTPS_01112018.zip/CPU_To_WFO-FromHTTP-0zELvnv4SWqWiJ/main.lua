local validate = require 'validate'
local retry = require 'retry'

local temp=[[

<appointment>
<requestId></requestId>
<appointmentDate></appointmentDate>
<staffId_1></staffId_1>
<staffId_2></staffId_2>
<workspace></workspace>
<status></status>
<startTime></startTime>
<endTime></endTime>
</appointment>
]]

local responsetemp= [[
<status> 
<requestId></requestId>
<code></code>
<details></details>
</status>

]]

local function TrimField(F)


   for i=1, F.appointments:childCount('appointment') do
      -- for j=1, F.rosters:childCount("roster") do

      F.appointments:child("appointment", i).requestId:setInner(F.appointments:child("appointment", i).requestId:nodeText():trimWS())
      F.appointments:child("appointment", i).appointmentDate:setInner(F.appointments:child("appointment", i).appointmentDate:nodeText():trimWS())
      F.appointments:child("appointment", i).staffId_1:setInner(F.appointments:child("appointment", i).staffId_1:nodeText():trimWS())
      F.appointments:child("appointment", i).staffId_2:setInner(F.appointments:child("appointment", i).staffId_2:nodeText():trimWS())
      F.appointments:child("appointment", i).workspace:setInner(F.appointments:child("appointment", i).workspace:nodeText():trimWS())
      F.appointments:child("appointment", i).status:setInner(F.appointments:child("appointment", i).status:nodeText():trimWS())
      F.appointments:child("appointment", i).startTime:setInner(F.appointments:child("appointment", i).startTime:nodeText():trimWS())
      F.appointments:child("appointment", i).endTime:setInner(F.appointments:child("appointment", i).endTime:nodeText():trimWS())
   end
   return F
end

--local function ProcessMSG(XMLMsg)
-- local Errs = validate.CheckAdt(XMLMsg) 
-- if (#Errs > 0) then
-- Respond= net.http.respond{body="Error Occured " .. table.concat(Errs)}
--  return    Errs
--end
--end

function main(Data)


   local Result, R2, M = retry.call{func=DoInsert, retry=10, pause=10, funcname='DoInsert',arg1=Data}
   trace(Result)
   trace(R2)
   trace(M)

   if #R2 == 0 then 

      local response, status, headers = 
      net.http.post{url='http://localhost:6544/test.workforceoptimizer.com/api/wfo/appointments_response ', body = Result 
         , live=true,
         auth={username='sysadmin@stgsgh49.com',password='Password1'},headers={['Content-Type']='application/json'}}
      trace(response)

      --local responsetemplate=xml.parse{data=responsetemp}
      --local responseMSG=xml.parse{data=response}
      --local Response=mapresponse(responsetemplate,responseMSG)


      -- Log the response and status code
      if status == 200 then
        -- iguana.logDebug("Request successful: " .. response .. " (" .. status .. ")")  
          iguana.logInfo("Request Successful" .. response .. "(" .. status .. ")")  
         net.http.respond{body="Code :\t " .. status .. "Success \n" .. response}
      elseif status == 400 then
         --iguana.logDebug("Validation Error: "  .. response .. " (" .. status .. ")") 
         iguana.logInfo("Validation Error" .. response .. "(" .. status .. ")") 
         net.http.respond{body="Code :\t " .. status ..", error: Validation Error \n "..response}
      elseif status == 401 then
         --iguana.logDebug("Unauthorize Error: " .. response .. "(" .. status .. ")")
         iguana.logInfo("Unauthorize Error" .. response .. "(" .. status .. ")") 
         net.http.respond{body="Code :\t " .. status .. ", error: Unauthorize Error \n"..response}
      elseif status == 500 then
         --iguana.logDebug("error Internal Server Error" .. response .. "(" .. status .. ")")
         iguana.logInfo("error Internal Server Error" .. response .. "(" .. status .. ")") 
         net.http.respond{body="Code :\t " .. status .. ", error: Internal Server Error \n"..response}
      else
         --iguana.logDebug("Request unsuccessful: "  .. response ..  "(" .. status .. ")")
         iguana.logInfo("Request unsuccessful" .. response .. "(" .. status .. ")") 
         net.http.respond{body="Request unsuccessful"  .. "\t".. status.."\t" ..  response}

      end
   else
      net.http.respond{body=" Error Occured " .. table.concat(R2)}
      print("error Occured")
      iguana.logDebug("Error Occured" .. table.concat(R2))
   end
end

function DoInsert(Data)
   --Parse the incoming request
   Request = net.http.parseRequest{data=Data}
   --log the info 
   iguana.logInfo(Data)
   --parse the xml message
   ParseMsg= xml.parse{data=Request.body}
   --trim whitespce before and after
   local XMLMsg= TrimField(ParseMsg)
   --parse XML template
   local XMLTemplate=xml.parse{data=temp}


   --start validating
   local ValidateErrs=validate.CheckAdt(XMLMsg)

   if  #ValidateErrs == 0 then

      --mapping the data
      local Result = mapdata(XMLTemplate,XMLMsg)
      queue.push{data=Result}
      trace(Result)
      return Result,ValidateErrs
   end

   return Result,ValidateErrs

end

function mapdata(Xml,XMLMsg)
   Result = {}


   for i=1, XMLMsg.appointments:childCount('appointment') do


      Xml.appointment.requestId:setInner(XMLMsg.appointments:child("appointment", i).requestId:nodeText())
      Xml.appointment.appointmentDate:setInner(XMLMsg.appointments:child("appointment", i).appointmentDate:nodeText())
      Xml.appointment.staffId_1:setInner(XMLMsg.appointments:child("appointment", i).staffId_1:nodeText())
      Xml.appointment.staffId_2:setInner(XMLMsg.appointments:child("appointment", i).staffId_2:nodeText())
      Xml.appointment.workspace:setInner(XMLMsg.appointments:child("appointment", i).workspace:nodeText())
      Xml.appointment.status:setInner(XMLMsg.appointments:child("appointment", i).status:nodeText())
      Xml.appointment.startTime:setInner(XMLMsg.appointments:child("appointment", i).startTime:nodeText())
      Xml.appointment.endTime:setInner(XMLMsg.appointments:child("appointment", i).endTime:nodeText())

      trace(Xml)




      Result[i]=Xml:S().."\n"
   end   
   return formatresult(Result)
end




function formatresult(Result)
   --trace(#Result)
   local Output = 
   "<appointments>\n"..table.concat(Result).."</appointments>"
   return Output,'text/xml'
end

--function mapresponse(resp,responseMSG)
--Response = {}
--for i=1, respopnse do
--resp.status.requestId=responseMSG.requestId[i]
--   if responseMSG.status == "success" then
 --   resp.status.code:setInner("Created")
--     resp.status.details:setInner("")
--  end
-- if responseMSG.status == "Error" then
--  resp.status.code:setInner("Error")
 --  resp.status.details:setInner("Appointment Not Found")
-- end
--  Response[i]=resp:S().."\n"
--  end
-- return Response
--end

--function formatresponse(Reponse)
-- local Output2 = 
-- "<appointmentstatus>\n"..table.concat(Response).."</appointmentstatus>"
-- return Output2,'text/xml'
--end








