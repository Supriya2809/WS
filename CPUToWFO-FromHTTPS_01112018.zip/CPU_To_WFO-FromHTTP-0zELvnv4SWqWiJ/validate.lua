local codemap = require 'codemap' 
 
local validate={}


local AppStatus = codemap.set{'A', 'C'}

 
local function Add(List, Msg)
   List[#List+1] = Msg
end
 
local function EmptyList()
   local List = {}
   List.add = Add
   return List
end
 
local function RequiredField(Errs, F, Message, requestid)
   if F:nodeText() == '' then
      Errs:add(Message..' is missing. Mandatory field '.. requestid:nodeText())
      return Errs[#Errs]
   end
end
 

local function FieldLength(Errs, len, F, Message, rosterid)
   if string.len( F:nodeText())> len then
      Errs:add(Message .. " has exceeded the string lenght limit for roster id " .. rosterid:nodeText() .." Limit is: " .. len)
      return Errs[#Errs]
   end
end
local  function ComputeTime(Errs, starttime, endtime, rosterid)
   time=os.ts.difftime(endtime:nodeText(),starttime:nodeText())
   trace(time)
   if time < 0 then
      Errs:add("Start Time (".. starttime:nodeText().. ") is greater than End Time (" 
         .. endtime:nodeText() .. ") for roster id " .. rosterid:nodeText())
   return Errs[#Errs]   
   end

end

local function PrintSet(Set)
   local R =''
   for K in pairs(Set) do
      R = R..",'"..K.."'"
   end
   R = '['..R:sub(2, #R)..']'
   return R
end

local function FieldMatchCode(Errs, Set, F, Message,appointmentid)
   if not Set[F:nodeText()] then
      Errs:add(Message.." has unnacceptable values for appointment id " .. appointmentid:nodeText())
      return Errs[#Errs]
   end
end

 
local function CheckPID(XMLMsg, Errs)
   for i=1, XMLMsg.appointments:childCount('appointment') do
   RequiredField(Errs, XMLMsg.appointments:child("appointment", i).requestId, XMLMsg.appointments:child("appointment", i).requestId)
   RequiredField(Errs, XMLMsg.appointments:child("appointment", i).appointmentDate, 'appointment date', XMLMsg.appointments:child("appointment", i).requestId)
   RequiredField(Errs, XMLMsg.appointments:child("appointment", i).staffId_1, 'staffId_1', XMLMsg.appointments:child("appointment", i).requestId)
   RequiredField(Errs, XMLMsg.appointments:child("appointment", i).staffId_2, 'staffId_2', XMLMsg.appointments:child("appointment", i).requestId)
   RequiredField(Errs, XMLMsg.appointments:child("appointment", i).workspace, 'workspace', XMLMsg.appointments:child("appointment", i).requestId)
   RequiredField(Errs, XMLMsg.appointments:child("appointment", i).status, 'status', XMLMsg.appointments:child("appointment", i).requestId)
   RequiredField(Errs, XMLMsg.appointments:child("appointment", i).startTime, 'startTime', XMLMsg.appointments:child("appointment", i).requestId)
   RequiredField(Errs, XMLMsg.appointments:child("appointment", i).endTime, 'endTimen', XMLMsg.appointments:child("appointment", i).requestId)
   
   FieldMatchCode(Errs, AppStatus,  XMLMsg.appointments:child("appointment", i).status,'Appointment Status', XMLMsg.appointments:child("appointment", i).requestId)
   
   ComputeTime(Errs, XMLMsg.appointments:child("appointment", i).startTime, XMLMsg.appointments:child("appointment", i).endTime, XMLMsg.appointments:child("appointment", i).requestId)
   --FieldLength(Errs, IDLength, XMLMsg.appointments:child("appointment", i).requestId , 'roster.id', XMLMsg.appointments:child("appointment", i).requestId)
  
   end
end
 
function validate.CheckAdt(XMLMsg)
   local ErrList = EmptyList()   
   CheckPID(XMLMsg, ErrList)
   ErrList.add = nil
   return ErrList
end


--modify the function call to match the code for shift code)


 
return validate