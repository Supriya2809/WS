local Webpage = {}

Webpage.text = [[   
<h1>
   Redirecting
</h1>

<p>To use this web service, please supply the following parameters:</p>

<p>The following are pre-formatted requests that you can use to search for a patient with the last name "Smith".  Just click and go!</p>

<p>
   Return the results as XML: <a href='?LastName=Smith&Format=xml'>http://localhost:6544/example/test2</a><br>
   Return the results as JSON: <a href='?LastName=Smith&Format=json'>http://localhost:6544/lookup?LastName=Smith&Format=json</a>
</p>
]]

return Webpage